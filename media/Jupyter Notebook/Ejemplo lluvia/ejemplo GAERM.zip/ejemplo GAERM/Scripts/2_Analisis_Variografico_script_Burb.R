#--------------------------------------------------------------#
#                   Variography Analysis                       #
#--------------------------------------------------------------#

root_dir<-getwd()

# Creates a folder to store results for a case
# dir.create(paste(getwd(),"/Results/Burb", sep=""))
# 
# result_dir<-paste(root_dir,"/Results/Burb",sep="")

# Creates a folder to store results for Variography Analysis (AV)
dir.create(paste(getwd(),"/Results/Burb/AV", sep=""))

av_dir<-paste(root_dir,"/Results/Burb/AV",sep="")

#--------------------------------------------------------------#
#                    Spatial Distribution                      #
#--------------------------------------------------------------#

png(paste(av_dir,"/perm_mD_Spatial_Distr.png",sep=""))
DEspacial(XCoord, YCoord, perm_mD,
          'X (ft)', 'Y (ft)', 'Permeability (mD)', 'Permeability Spatial Distribution')
dev.off()

#--------------------------------------------------------------#
#               Trend (Stationarity) Analysis                  #
#--------------------------------------------------------------#

# Median Regression Analysis in X and Y directions for variable perm_mD
png(paste(av_dir,"/perm_mD_Trend_X_Y.png",sep=""), bg = "white")
GDirecciones(XCoord, YCoord, perm_mD)
dev.off()

# Estimation of the experimental variogram
X_rng<-XCoord_Stat[8,2]
Y_rng<-YCoord_Stat[8,2]
N_lags<-10
lag_value <- sqrt(X_rng*X_rng+Y_rng*Y_rng)/(2*N_lags)
DistMin<-min(dist(Data_File_Burb[,1:2])) # Minimum distance in data
DistMax<-max(dist(Data_File_Burb[,1:2])) # Minimum distance in data
lag_value<-max((DistMax/2)/N_lags, DistMin)
png(paste(av_dir,"/perm_mD_VarioEstimation.png",sep=""), bg = "white")
perm_mD_VarioEstimation<-Variograma(XCoord, YCoord, 
                                         perm_mD, 0, 90, N_lags, lag_value, 1, "Variograma Adireccional de perm_mD")
dev.off()

# Displaying the variogram estimated values
perm_mD_VarioEstimation
write.csv(perm_mD_VarioEstimation, file = paste(av_dir,"/perm_mD_Vario_Adireccional.csv",sep=""))

# Polynomial Trend Surface Estimation (degree = 1)
pol_degree=1
perm_mD_Detrended_1<-Trend(XCoord, YCoord, 
                                perm_mD, pol_degree) 

# Median Regression Analysis in X and Y directions for residuals perm_mD_Detrended_1
png("Results/AnalisisEstructuralRadar/perm_mD_Detrended_1.png", bg = "white")
GDirecciones(perm_mD_Detrended_1[,1], perm_mD_Detrended_1[,2], perm_mD_Detrended_1[,3])
dev.off()

# Estimation of the experimental variogram (Detrended_1)
png("Results/AnalisisEstructuralRadar/perm_mD_Detrended_1_VarioEstimation.png", bg = "white")
perm_mD_Detrended_1_VarioEstimation<-Variograma(perm_mD_Detrended_1[,1], perm_mD_Detrended_1[,2], 
                                                     perm_mD_Detrended_1[,3], 0, 90, N_lags, lag_value, 1, 
                                                     "Variograma Adireccional de perm_mD Residuos 1")
dev.off()

# Polynomial Trend Surface Estimation (degree = 2)
pol_degree=2
perm_mD_Detrended_2<-Trend(XCoord, YCoord, 
                                perm_mD, pol_degree) 

# Median Regression Analysis in X and Y directions for residuals perm_mD_Detrended_1
png("Results/AnalisisEstructuralRadar/perm_mD_Detrended_2.png", bg = "white")
GDirecciones(perm_mD_Detrended_2[,1], perm_mD_Detrended_2[,2], perm_mD_Detrended_2[,3])
dev.off()

# Estimation of the experimental variogram (Detrended_2)
png("Results/AnalisisEstructuralRadar/perm_mD_Detrended_2_VarioEstimation.png", bg = "white")
perm_mD_Detrended_2_VarioEstimation<-Variograma(perm_mD_Detrended_2[,1], perm_mD_Detrended_2[,2], 
                                                     perm_mD_Detrended_2[,3], 0, 90, N_lags, lag_value, 1, 
                                                     "Variograma Adireccional de perm_mD Residuos 2")
dev.off()



#--------------------------------------------------------------#
#       Univariate Variography (Structural)  Modeling          #
#--------------------------------------------------------------#

# Estimation of the experimental variogram
png(paste(av_dir,"/perm_mD_VarioEstimation_dir45.png",sep=""), bg = "white")
perm_mD_VarioEstimation_dir45<-Variograma(XCoord, YCoord, 
                                         perm_mD, 45, 22.5, N_lags, lag_value, 1, "Variograma de perm_mD en la direccion de 45")
dev.off()
# Displaying the variogram estimated values
write.csv(perm_mD_VarioEstimation_dir45, file = paste(av_dir,"/perm_mD_Vario_direccio45.csv",sep=""))


# Directional Variograms in 4 directions (0, 45, 90 and 135)
png(paste(av_dir,"/perm_mD_Vario4DEstimation.png",sep=""), bg = "white")
perm_mD_VarioEstimation4D<-Variograma4D(XCoord, YCoord, 
                                         perm_mD, 0, 45, 90, 135, 22.5, N_lags, lag_value, 1, "Variogramas Direccionales de perm_mD")
dev.off()
# Displaying the four directional estimated variogram values
perm_mD_VarioEstimation4D
write.csv(perm_mD_VarioEstimation4D, file = paste(av_dir,"/perm_mD_VarioEstimation4D.csv",sep=""))

# Automatic Variogram Model Fitting
png(paste(av_dir,"/perm_mD_VarioAllModelEstimation.png",sep=""), bg = "white")
perm_mD_AllModelVarioFit<-AllModel(XCoord, YCoord, 
                                    perm_mD, 0, 90, N_lags, lag_value, 1, "Ajustes del Variograma Adireccional de perm_mD")
dev.off()
# Displaying Automatic Variogram Model Fitting
perm_mD_AllModelVarioFit
write.csv(perm_mD_VarioEstimation4D, file = paste(av_dir,"/perm_mD_AllModelVarioFit.csv",sep=""))

# Best Automatic Variogram Model Fitting
#VariogramBestModel<-BestModel(Data[,1], Data[,2], Data[,3], 0, 90, 10, 150, 1, 'Elevation_of_seam Variogram')
png(paste(av_dir,"/perm_mD_VarioBestModelEstimation.png",sep=""),  bg = "white")
perm_mD_BestModelVarioFit<-BestModel(XCoord, YCoord, 
                                      perm_mD, 0, 90, N_lags, lag_value, 1, "Mejor Ajuste del Variograma Adireccional de perm_mD")
dev.off()
# Displaying Best Automatic Variogram Model Fitting
perm_mD_BestModelVarioFit

# Manual Variogram Model Fitting
#modelos de variograma (1- exponential, 2- spherical, 3- gaussian)
vario_model<- 2
nugget<- 24000000
sill_and_nugget<- 84000000
rank <- 7000

perm_mD_vario_model<- 2
perm_mD_nugget<- 24000000
perm_mD_sill_and_nugget<- 84000000
perm_mD_rank <- 7000
png(paste(av_dir,"/perm_mD_VarioEyeEstimation.png",sep=""),  bg = "white")
perm_mD_EyeModelVarioFit<-EyeModel(XCoord, YCoord, 
                                    perm_mD, 0, 90, N_lags, lag_value, 1, 
                                    perm_mD_vario_model, perm_mD_nugget, perm_mD_sill_and_nugget, perm_mD_rank,
                                    "Ajuste Manual del Variograma Adireccional de perm_mD")
dev.off()

# Variogram Model Cross Validation
library(gstat)
library(geoR)
perm_mD_CrossValid<- CrossValidation(XCoord, YCoord, 
                                      perm_mD, vario_model, nugget, sill_and_nugget, rank)

# Statistical Analysis of differences (Z-Z*)

# Basic Statistics in a single table
perm_mD_CrossValid_Sta <- Val_Estadisticos(perm_mD_CrossValid[1:102,c(3,4,5)])
write.csv(perm_mD_CrossValid_Sta, file = paste(av_dir,"/perm_mD_CrossValid_Sta.csv",sep=""))

# Histogram and Boxplot 1
png(paste(av_dir,"/perm_mD-perm_mD+_HistBoxPlot1.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD_CrossValid[,5], mean = perm_mD_CrossValid_Sta[5,3], median = perm_mD_CrossValid_Sta[4,3], main ="", 
            xlab = "perm_mD-perm_mD* (mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE )
dev.off()

# Spatial Distribution of differences (Z-Z*)
png(paste(av_dir,"/perm_mD_CrossValid_Spatial_Distr.png",sep=""), bg = "white")
DEspacial(perm_mD_CrossValid[,1], perm_mD_CrossValid[,2], perm_mD_CrossValid[,5],
          'X (ft)', 'Y (ft)', 'perm_mD-perm_mD* (mD)', 'perm_mD - perm_mD*')
dev.off()

pos1 <- which(perm_mD_CrossValid[,5] > 1.3)
pos0 <- which(perm_mD_CrossValid[,5] < -2)

# Scatterplot with linear correlation coefficient

# perm_mD is the independent variable
X<-perm_mD_CrossValid[,3]
# perm_mD* is the dependent variable
Y<-perm_mD_CrossValid[,4]

png(paste(av_dir,"/perm_mD-perm_mD+_ScatterPlot.png",sep=""), bg = "white")
scaterplotReg(perm_mD_CrossValid[,3] , perm_mD_CrossValid[,4], 9, 
            Xmin = perm_mD_CrossValid_Sta[2,1], Xmax = perm_mD_CrossValid_Sta[7,1], 
            Ymin = perm_mD_CrossValid_Sta[2,2],Ymax = perm_mD_CrossValid_Sta[7,2], 
            XLAB = "perm_mD (mD)", YLAB = "perm_mD* (mD)")
dev.off()

png(paste(av_dir,"/perm_mD-perm_mD_diff_ScatterPlot.png",sep=""), bg = "white")
scaterplotReg(perm_mD_CrossValid[,3] , perm_mD_CrossValid[,5], 9, 
            Xmin = perm_mD_CrossValid_Sta[2,1], Xmax = perm_mD_CrossValid_Sta[7,1], 
            Ymin = perm_mD_CrossValid_Sta[2,2],Ymax = perm_mD_CrossValid_Sta[7,2], 
            XLAB = "perm_mD (mD)", YLAB = "perm_mD (mD)-perm_mD* (mD)")
dev.off()