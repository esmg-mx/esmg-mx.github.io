#### ------- RGeoestad script in 2D ------- ####


#--------------------------------------------------------------#
#                   Data Manipulation                          #
#--------------------------------------------------------------#

root_dir<-getwd()

# Reading Data File in ASCII format space separated (.txt)
# -999.25 for non available values
#Data_File <- read.table(file=file.choose(),header=TRUE,na.strings="-999.25")

# Reading Data File in ASCII format comma separated (.csv)
# -999.25 for non available values
Data_File_Burb <- read.csv(file=file.choose(),header=T,na.strings="-999.25")

# Creates a folder to store results for a case
dir.create(paste(getwd(),"/Results/Burb", sep=""))

result_dir<-paste(root_dir,"/Results/Burb",sep="")

# Creates a folder to store results for AED
dir.create(paste(getwd(),"/Results/Burb/AED", sep=""))

aed_dir<-paste(result_dir,"/AED",sep="")

XCoord<-Data_File_Burb$Easting_ft
YCoord<-Data_File_Burb$Northing_ft
phi_per<-Data_File_Burb$phi_percent
perm_mD<-Data_File_Burb$k_mD
  
#--------------------------------------------------------------#
#               Exploratory Data Analysis                      #
#--------------------------------------------------------------#


###------------ Univariate Data Analysis---------------------###

# Basic Statistics Estimation 

# Basic Statistics
XCoord_Stat<-Estadisticas(XCoord)
YCoord_Stat<-Estadisticas(YCoord)
phi_per_Stat<-Estadisticas(phi_per)
perm_mD_Stat<-Estadisticas(perm_mD)

# Basic Statistics in a single table
Data_File_Burb_Stat <- Val_Estadisticos(Data_File_Burb)
write.csv(Data_File_Burb_Stat , file = paste(aed_dir,"/Data_File_Burb_Stat.csv",sep=""))

############  phi_per data
# Histogram and Boxplot
# Save plot as image in png format
png(paste(aed_dir,"/phi_per_HistBoxPlotCounts.png",sep=""), bg = "white")
HistBoxplot(x=phi_per, mean = phi_per_Stat[5,2], median = phi_per_Stat[4,2], main ="",  
            xlab = "porosity (%)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
            nbin = 9)
dev.off()
png(paste(aed_dir,"/phi_per_HistBoxPlotFreq.png",sep=""), bg = "white")
HistBoxplot(x=phi_per, mean = phi_per_Stat[5,2], median = phi_per_Stat[4,2], main ="", 
            xlab = "porosity (%)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
            nbin = 9)
dev.off()

# Distributional Outliers Detection and Identification
phi_per_outliers<-OutliersPos(phi_per)
Data_File_Burb[phi_per_outliers,c(1,2,3)] # Shows the outliers
# Variable without distributional outliers

# phi_per_out<-phi_per[-phi_per_outliers]

# Data Analysis without Outliers

# Make the previous analysis without outliers

## OUTLIERS

# # Basic Statistics
# phi_per_out_Stat<-Estadisticas(phi_per_out)
# 
# # Histogram and Boxplot
# png(paste(aed_dir,"/phi_per_out_HistBoxPlotCounts.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_out, mean = phi_per_out_Stat[5,2], median = phi_per_out_Stat[4,2], main ="",  
#             xlab = "phi_per_out (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
#             nbin = 9)
# dev.off()
# png(paste(aed_dir,"/phi_per_out_HistBoxPlotFreq.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_out, mean = phi_per_out_Stat[5,2], median = phi_per_out_Stat[4,2], main ="", 
#             xlab = "phi_per_out (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
#             nbin = 9)
# dev.off()
# 
# # Distributional Outliers Detection and Identification
# phi_per_out_outliers<-OutliersPos(phi_per_out)

#---------------------Variable Transformations--------------------------------#
# # SQUARE ROOT TRANSFORMATION
# Data_File_Burb$phi_per_Sqrt<-sqrt(phi_per)
# phi_per_Sqrt <- Data_File_Burb$phi_per_Sqrt
# 
# # Basic Statistics
# phi_per_Sqrt_Stat<-Estadisticas(phi_per_Sqrt)
# 
# # Basic Statistics in a single table
# Data_File_Burb_Stat <- Val_Estadisticos(Data_File_Burb)
# 
# # Histogram and Boxplot
# png(paste(aed_dir,"/phi_per_Sqrt_HistBoxPlotCounts.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Sqrt, mean = phi_per_Sqrt_Stat[5,2], median = phi_per_Sqrt_Stat[4,2], main ="",  
#             xlab = "phi_per_Sqrt (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
#             nbin = 9)
# dev.off()
# png(paste(aed_dir,"/phi_per_Sqrt_HistBoxPlotFreq.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Sqrt, mean = phi_per_Sqrt_Stat[5,2], median = phi_per_Sqrt_Stat[4,2], main ="", 
#             xlab = "phi_per_Sqrt (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
#             nbin = 9)
# dev.off()
# 
# # Distributional Outliers Detection and Identification
# 
# phi_per_Sqrt_outliers<-OutliersPos(phi_per_Sqrt)
# Data_File_Burb[phi_per_Sqrt_outliers,c(1,2,5)] # Shows the outliers
# # Variable without distributional outliers
# phi_per_Sqrt_out<-phi_per_Sqrt[-phi_per_Sqrt_outliers]
# 
# # no more outliers detected
# OutliersPos(phi_per_Sqrt_out)
# 
# # LOGARITMIC TRANSFORMATION
# Data_File_Burb$phi_per_Log<-log(phi_per)
# phi_per_Log <- Data_File_Burb$phi_per_Log
# 
# # Basic Statistics
# phi_per_Log_Stat<-Estadisticas(phi_per_Log)
# 
# # Basic Statistics in a single table
# Data_File_Burb_Stat <- Val_Estadisticos(Data_File_Burb)
# 
# # Histogram and Boxplot
# png(paste(aed_dir,"/phi_per_Log_HistBoxPlotCounts.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Log, mean = phi_per_Log_Stat[5,2], median = phi_per_Log_Stat[4,2], main ="",  
#             xlab = "phi_per_Log (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
#             nbin = 9)
# dev.off()
# png(paste(aed_dir,"/phi_per_Log_HistBoxPlotFreq.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Log, mean = phi_per_Log_Stat[5,2], median = phi_per_Log_Stat[4,2], main ="", 
#             xlab = "phi_per_Log (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
#             nbin = 9)
# dev.off()
# 
# # Distributional Outliers Detection and Identification
# phi_per_Log_outliers<-OutliersPos(phi_per_Log)
# Data_File_Burb[phi_per_Log_outliers,c(1,2,6)] # Shows the outliers
# # Variable without distributional outliers
# phi_per_Log_out<-phi_per_Log[-phi_per_Log_outliers]
# # Data Analysis without Outliers
# 
# # Basic Statistics
# phi_per_Log_out_Stat<-Estadisticas(phi_per_Log_out)
# 
# png(paste(aed_dir,"/phi_per_Log_out_HistBoxPlotFreq.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Log_out, mean = phi_per_Log_out_Stat[5,2], median = phi_per_Log_out_Stat[4,2], main ="", 
#             xlab = "phi_per_Log_out (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
#             nbin = 9)
# dev.off()
# 
# # Distributional Outliers Detection and Identification 2
# phi_per_Log_outliers2<-OutliersPos(phi_per_Log_out)
# phi_per_Log_out[phi_per_Log_outliers2]
# 
# # Variable without distributional outliers 2
# phi_per_Log_out2<-phi_per_Log_out[-phi_per_Log_outliers2]
# 
# 
# # Data Analysis without Outliers 2
# # Basic Statistics in separated tables
# phi_per_Log_out2_Stat<-Estadisticas(phi_per_Log_out2)
# 
# png(paste(aed_dir,"/phi_per_Log_out2_HistBoxPlotFreq.png",sep=""), bg = "white")
# HistBoxplot(x=phi_per_Log_out2, mean = phi_per_Log_out2_Stat[5,2], median = phi_per_Log_out2_Stat[4,2], main ="", 
#             xlab = "phi_per_Log_out2 (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
#             nbin = 9)
# dev.off()

############  perm_mD data
# Basic Statistics
perm_mD_Stat <- Estadisticas(perm_mD)
png(paste(aed_dir,"/perm_mD_HistBoxPlotFreq.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD, mean = perm_mD_Stat[5,2], median = perm_mD_Stat[4,2], main ="", 
            xlab = "permeability (mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
            nbin = 9)
dev.off()
png(paste(aed_dir,"/perm_mD_HistBoxPlotCounts.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD, mean = perm_mD_Stat[5,2], median = perm_mD_Stat[4,2], main ="", 
            xlab = "permeability (mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
            nbin = 9)
dev.off()

Data_File_Burb$perm_mD_Log <- log(perm_mD)
perm_mD_Log <- log(perm_mD)

# Basic Statistics
perm_mD_Log_Stat <- Estadisticas(perm_mD_Log)
write.csv(perm_mD_Log_Stat , file = paste(aed_dir,"/perm_mD_Log_Stat.csv",sep=""))

png(paste(aed_dir,"/perm_mD_Log_HistBoxPlotFreq.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD_Log, mean = perm_mD_Log_Stat[5,2], median = perm_mD_Log_Stat[4,2], main ="", 
            xlab = "perm_mD_Log (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
            nbin = 9)
dev.off()
png(paste(aed_dir,"/perm_mD_Log_HistBoxPlotCounts.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD_Log, mean = perm_mD_Log_Stat[5,2], median = perm_mD_Log_Stat[4,2], main ="", 
            xlab = "perm_mD_Log (mm)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
            nbin = 9)
dev.off()

# QQ-Plot
# png(paste(aed_dir,"/perm_mD_Log_QQ_plot.png",sep=""), bg = "white")
# QQplot(x = perm_mD_Log, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "QQ-Plot", xlab = "Cuantiles teóricos", 
#        lcol = "red", lwd = 2)
# dev.off()

# PP-Plot
# png(paste(aed_dir,"/perm_mD_Log_PP_plot.png",sep=""), bg = "white")
# PPplot(x = perm_mD_Log, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "PP-Plot", xlab = "Probabilidades teóricas", 
#        lcol = "red", lwd = 2)
# dev.off()

# Distributional Outliers Detection and Identification
perm_mD_outliers<-OutliersPos(perm_mD)
Data_File_Burb[perm_mD_outliers,c(1,2,3)] # Shows the outliers
# Variable without distributional outliers

perm_mD_out<-perm_mD[-perm_mD_outliers]

# Data Analysis without Outliers

# Make the previous analysis without outliers

# OUTLIERS

# Basic Statistics
perm_mD_out_Stat<-Estadisticas(perm_mD_out)
write.csv(perm_mD_out_Stat , file = paste(aed_dir,"/perm_mD_out_Stat.csv",sep=""))

# Histogram and Boxplot
png(paste(aed_dir,"/perm_mD_out_HistBoxPlotCounts.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD_out, mean = perm_mD_out_Stat[5,2], median = perm_mD_out_Stat[4,2], main ="",  
            xlab = "perm_mD_out (mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE,
            nbin = 9)
dev.off()
png(paste(aed_dir,"/perm_mD_out_HistBoxPlotFreq.png",sep=""), bg = "white")
HistBoxplot(x=perm_mD_out, mean = perm_mD_out_Stat[5,2], median = perm_mD_out_Stat[4,2], main ="", 
            xlab = "perm_mD_out (mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = FALSE, PercentFreq = TRUE,
            nbin = 9)
dev.off()

# Distributional Outliers Detection and Identification
perm_mD_out_outliers<-OutliersPos(perm_mD_out)

###------------ Bivariate Data Analysis---------------------###
cor(phi_per , perm_mD, method = "pearson")
cor(phi_per , perm_mD, method = "spearman")
cor(phi_per , perm_mD, method = "kendall")

# Scatterplot with linear correlation coefficient
# phi_per is the independent variable (x-axis)
# perm_mD is the dependent variable (y-axis)
png(paste(aed_dir,"/phi_per-perm_mD_ScatterPlot.png",sep=""), bg = "white")
ScatterPlot(phi_per , perm_mD, 9, 
            Xmin = phi_per_Stat[2,2], Xmax = phi_per_Stat[7,2], 
            Ymin = perm_mD_Stat[2,2],Ymax = perm_mD_Stat[7,2], 
            XLAB = "porosity (%)", YLAB = "permeability (mD)")
dev.off()


###------------ Linear Regression Analysis----------------------------###

# Scatterplot with regression line

png(paste(aed_dir,"/phi_per-perm_mD_ScatterPlotReg.png",sep=""), bg = "white")
scaterplotReg(phi_per , perm_mD, 9, 
              Xmin = phi_per_Stat[2,2], Xmax = phi_per_Stat[7,2], 
              Ymin = perm_mD_Stat[2,2],Ymax = perm_mD_Stat[7,2], 
              XLAB = "porosity (%)", YLAB = "permeability (mD)")
dev.off()

# Linear Regression Parameters
B0 <- -7547.91
B1 <- 2079.75

# Regression line and Residual Calculation
X<-phi_per
Y<-perm_mD

Y_Regression <- B0 + B1*X
Y_Residual <- Y-Y_Regression

# Residual Statistical Analysis
# Basic Statistics
Y_Residual_Stat<-Estadisticas(Y_Residual)
write.csv(Y_Residual_Stat , file = paste(aed_dir,"/perm_mD_Residual_Stat.csv",sep=""))

# Histogram and Boxplot 1
png(paste(aed_dir,"/perm_mD_Residual_HistBoxPlot.png",sep=""), bg = "white")
HistBoxplot(x=Y_Residual, mean = Y_Residual_Stat[5,2], median = Y_Residual_Stat[4,2], main ="", 
            xlab = "Residuos perm_mD", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE )
dev.off()


# Fitting a Normal Distribution
png(paste(aed_dir,"/perm_mD_Residual_Fit.png",sep=""), bg = "white")
FitDistr2_Residual_normal<-FitDistribution(data = Y_Residual, DISTR="norm", BREAKS = "Sturges", col = "gray",  DistName = "Normal")
dev.off()

# Hypothesis Tests for Normality
FD_HT_Residual_normal<-FitDistr2_Residual_normal$x

# Normal Fitting Parameters
FD_FP_Residual_normal<-FitDistr2_Residual_normal$y

# Histogram Plotting with Fitting Distribution Curve
png(paste(aed_dir,"/perm_mD_Residual_Fit_hist.png",sep=""), bg = "white")
PARA_Residual_normal <- list(mean = as.numeric(FD_FP_Residual_normal[1,1]), sd = as.numeric(FD_FP_Residual_normal[2,1]))
HistModel(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, breaks = "Sturges", freq = FALSE, main ="Histograma y Ajuste", xlab = "perm_mD Residuos (mm)", 
          ylab = "Densidad", colCurve =  "red", col = "darkgray")
dev.off()

# Cummulative Distribution Function with Fitting Curve
png(paste(aed_dir,"/perm_mD_Residual_Fit_CDF.png",sep=""), bg = "white")
CDF(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "DPA y Ajuste", xlab = "perm_mD Residuos (mm)", 
    lcol = "red", lwd = 2)
dev.off()

# QQ-Plot
png(paste(aed_dir,"/perm_mD_Residual_Fit_QQplot.png",sep=""), bg = "white")
QQplot(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "QQ-Plot", xlab = "Cuantiles teóricos", 
       lcol = "red", lwd = 2)
dev.off()

# PP-Plot
png(paste(aed_dir,"/perm_mD_Residual_Fit_PPplot.png",sep=""), bg = "white")
PPplot(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "PP-Plot", xlab = "Probabilidades teóricas", 
       lcol = "red", lwd = 2)
dev.off()

###------------ Bivariate Analysis: Y vs Y_Residual ---------------------###

# Scatterplot with linear correlation coefficient
# Y_Residual is the independent variable
X<-Y_Residual
# perm_mD is the dependent variable
Y<-perm_mD

png(paste(aed_dir,"/perm_mD-Residual_ScatterPlot.png",sep=""), bg = "white")
ScatterPlot(X, Y, 9, 
           Xmin = Y_Residual_Stat[2,2], Xmax = Y_Residual_Stat[7,2], 
           Ymin = perm_mD_Stat[2,2],Ymax = perm_mD_Stat[7,2], XLAB = "Residuos permeability (mD)", YLAB = "permeability (mD)")
dev.off()

###------------ Bivariate Data Analysis---------------------###
######## TRANSFORMED DATA

png(paste(aed_dir,"/phi_per-perm_mD_Log_ScatterPlot.png",sep=""), bg = "white")
ScatterPlot(phi_per , perm_mD_Log, 9, 
            Xmin = phi_per_Stat[2,2], Xmax = phi_per_Stat[7,2], 
            Ymin = perm_mD_Log_Stat[2,2],Ymax = perm_mD_Log_Stat[7,2], 
            XLAB = "phi_per (%)", YLAB = "log_perm_mD (log_mD)")
dev.off()


###------------ Linear Regression Analysis----------------------------###

# Scatterplot with regression line

png(paste(aed_dir,"/phi_per-perm_mD_Log_ScatterPlotReg.png",sep=""), bg = "white")
scaterplotReg(phi_per , perm_mD_Log, 9, 
              Xmin = phi_per_Stat[2,2], Xmax = phi_per_Stat[7,2], 
              Ymin = perm_mD_Log_Stat[2,2],Ymax = perm_mD_Log_Stat[7,2], 
              XLAB = "phi_per (%)", YLAB = "log_perm_mD (log_mD)")
dev.off()

# Linear Regression Parameters

B0 <- 4.31
B1 <- 0.50

# Regression line and Residual Calculation
X<-phi_per
Y<-perm_mD_Log

Y_Regression <- B0 + B1*X
Y_Residual <- Y-Y_Regression

# Residual Statistical Analysis

# Basic Statistics
Y_Residual_Stat<-Estadisticas(Y_Residual)
write.csv(Y_Residual_Stat , file = paste(aed_dir,"/perm_mD_Log_Residual_Stat.csv",sep=""))

# Histogram and Boxplot
png(paste(aed_dir,"/perm_mD_Log_Residual_HistBoxPlot.png",sep=""), bg = "white")
HistBoxplot(x=Y_Residual, mean = Y_Residual_Stat[5,2], median = Y_Residual_Stat[4,2], main ="", 
            xlab = "Residuos log_perm_mD (log mD)", ylab = "Frecuencia Absoluta (conteo)", AbsFreq = TRUE, PercentFreq = FALSE )
dev.off()


# Fitting a Normal Distribution
png(paste(aed_dir,"/perm_mD_Log_Residual_Fit.png",sep=""), bg = "white")
FitDistr2_Residual_normal<-FitDistribution(data = Y_Residual, DISTR="norm", BREAKS = "Sturges", col = "darkgray", DistName = "Normal")
dev.off()

# Hypothesis Tests for Normality

FD_HT_Residual_normal<-FitDistr2_Residual_normal$x

# Normal Fitting Parameters

FD_FP_Residual_normal<-FitDistr2_Residual_normal$y

# Histogram Plotting with Fitting Distribution Curve
png(paste(aed_dir,"/perm_mD_Log_Residual_Fit_hist.png",sep=""), bg = "white")
PARA_Residual_normal <- list(mean = as.numeric(FD_FP_Residual_normal[1,1]), sd = as.numeric(FD_FP_Residual_normal[2,1]))
HistModel(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, breaks = "Sturges", freq = FALSE, main ="Histograma y Ajuste", xlab = "perm_mD Residuos (mm)", 
          ylab = "Densidad", colCurve =  "red", col = "darkgray")
dev.off()

# Cummulative Distribution Function with Fitting Curve
png(paste(aed_dir,"/perm_mD_Log_Residual_Fit_CDF.png",sep=""), bg = "white")
CDF(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "DPA y Ajuste", xlab = "perm_mD Residuos (mm)", 
    lcol = "red", lwd = 2)
dev.off()

# QQ-Plot
png(paste(aed_dir,"/perm_mD_Log_Residual_Fit_QQplot.png",sep=""), bg = "white")
QQplot(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "QQ-Plot", xlab = "Cuantiles te?ricos", 
       lcol = "red", lwd = 2)
dev.off()

# PP-Plot
png(paste(aed_dir,"/perm_mD_Log_Residual_Fit_PPplot.png",sep=""), bg = "white")
PPplot(x = Y_Residual, distr = "norm", para = PARA_Residual_normal, col = "gray", main = "PP-Plot", xlab = "Probabilidades te?ricas", 
       lcol = "red", lwd = 2)
dev.off()

###------------ Bivariate Analysis: Y vs Y_Residual ---------------------###

# Scatterplot with linear correlation coefficient

# Y_Residual is the independent variable
X<-Y_Residual
# perm_mD_Log is the dependent variable
Y<-perm_mD_Log

png(paste(aed_dir,"/perm_mD_Log-Residual_ScatterPlot.png",sep=""), bg = "white")
ScatterPlot(X, Y, 9, 
           Xmin = Y_Residual_Stat[2,2], Xmax = Y_Residual_Stat[7,2], 
           Ymin = perm_mD_Log_Stat[2,2],Ymax = perm_mD_Log_Stat[7,2], XLAB = "Residuos log_perm_mD (log mD)", YLAB = "log_perm_mD (log mD)")
dev.off()

#--------------------------------------------------------------#
#                    Spatial Distribution                      #
#--------------------------------------------------------------#

# png(paste(aed_dir,"/phi_per_Spatial_Distr.png",sep=""), bg = "white")
# DEspacial(XCoord, YCoord, phi_per,
#           "X (UTM)", 'Y (UTM)', 'porosity (%)', 'phi_per Spatial Distribution ')
# dev.off()
# 
# png(paste(aed_dir,"/perm_mD_Spatial_Distr.png",sep=""), bg = "white")
# DEspacial(XCoord, YCoord, perm_mD,
#           'X (UTM)', 'Y (UTM)', 'permeability (mD)', 'perm_mD Spatial Distribution ')
# dev.off()
