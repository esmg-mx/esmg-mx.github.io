# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

#' Title RGeostad2D
#'
#'

#' #' @library Rcpp maps mapproj actuar fields fitdistrplus gstat MASS moments poweRlaw RFOC spatstat ADGofTest reshape sp
#'
#' @examples
hello <- function() {
  print("Hello, user!")
}
